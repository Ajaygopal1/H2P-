'use strict';
// Home2Place backend. Zero dependencies: Node 22.5+ (built-in http, crypto, sqlite).
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

// ---- config (reads .env if present) ----
try {
  fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split('\n').forEach(l => {
    const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2];
  });
} catch (e) {}
const PORT = +process.env.PORT || 3000;
const SECRET = process.env.SECRET || 'dev-secret-change-me';
const DEV_OTP = process.env.DEV_OTP !== '0';
const ADMIN_PHONE = process.env.ADMIN_PHONE || '';
const RZP_ID = process.env.RAZORPAY_KEY_ID, RZP_SECRET = process.env.RAZORPAY_KEY_SECRET;
const PRICE = { base: 30, perKm: 5.2, fee: 5 };

// ---- database ----
const db = new DatabaseSync(process.env.DB_FILE || path.join(__dirname, 'home2place.db'));
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, phone TEXT UNIQUE, name TEXT, role TEXT, partner_status TEXT, created TEXT);
CREATE TABLE IF NOT EXISTS otps(phone TEXT PRIMARY KEY, code TEXT, exp INTEGER, tries INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS orders(
 id TEXT PRIMARY KEY, customer_id INTEGER, partner_id INTEGER, item TEXT, status TEXT,
 pickup_addr TEXT, pickup_name TEXT, pickup_phone TEXT, drop_addr TEXT,
 rec_name TEXT, rec_phone TEXT, rec_note TEXT, schedule TEXT,
 km REAL, base INTEGER, dist INTEGER, fee INTEGER, total INTEGER, partner_pay INTEGER,
 pay_method TEXT, pay_status TEXT, rzp_order TEXT, delivery_otp TEXT, created TEXT);
CREATE TABLE IF NOT EXISTS events(order_id TEXT, status TEXT, at TEXT);
`);

// ---- helpers ----
const now = () => new Date().toISOString();
const b64 = s => Buffer.from(s).toString('base64url');
const sign = s => crypto.createHmac('sha256', SECRET).update(s).digest('base64url');
function makeToken(u) { const p = b64(JSON.stringify({ uid: u.id, role: u.role, exp: Date.now() + 30 * 864e5 })); return p + '.' + sign(p); }
function readToken(t) {
  if (!t) return null; const [p, s] = t.split('.');
  if (!p || !s || sign(p) !== s) return null;
  try { const d = JSON.parse(Buffer.from(p, 'base64url')); return d.exp > Date.now() ? d : null; } catch (e) { return null; }
}
const quote = km => { const dist = Math.round(km * PRICE.perKm); return { km, base: PRICE.base, dist, fee: PRICE.fee, total: PRICE.base + dist + PRICE.fee, partner_pay: PRICE.base + dist }; };
class HttpError extends Error { constructor(c, m) { super(m); this.code = c; } }
const bad = (c, m) => { throw new HttpError(c, m); };
const phoneOk = p => /^\+?\d{10,13}$/.test(String(p || '').replace(/\s/g, ''));
const normPhone = p => { p = String(p).replace(/\s/g, ''); return p.startsWith('+') ? p : (p.length === 10 ? '+91' + p : '+' + p); };
function event(id, status) { db.prepare('INSERT INTO events VALUES(?,?,?)').run(id, status, now()); }
function publicOrder(o, role) {
  if (!o) return null;
  const r = { ...o }; delete r.rzp_order;
  if (role === 'partner') { delete r.delivery_otp; delete r.total; }
  r.timeline = db.prepare('SELECT status, at FROM events WHERE order_id=? ORDER BY at').all(o.id);
  return r;
}
async function sendSms(phone, text) { // plug in MSG91 / Twilio / Fast2SMS here
  console.log(`[SMS to ${phone}] ${text}`);
}

// ---- payments (Razorpay or simulated) ----
async function rzpCreate(amountRupees, receipt) {
  if (!RZP_ID || !RZP_SECRET) return { dev: true, id: 'dev_' + crypto.randomBytes(6).toString('hex') };
  const r = await fetch('https://api.razorpay.com/v1/orders', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Basic ' + Buffer.from(RZP_ID + ':' + RZP_SECRET).toString('base64') },
    body: JSON.stringify({ amount: amountRupees * 100, currency: 'INR', receipt })
  });
  const j = await r.json(); if (!r.ok) bad(502, 'Payment provider error'); return j;
}
function rzpVerify(orderId, paymentId, signature) {
  if (!RZP_SECRET) return String(orderId).startsWith('dev_');
  const exp = crypto.createHmac('sha256', RZP_SECRET).update(orderId + '|' + paymentId).digest('hex');
  return exp.length === String(signature).length && crypto.timingSafeEqual(Buffer.from(exp), Buffer.from(String(signature)));
}

// ---- routes ----
const routes = [];
const route = (method, pattern, roles, fn) => routes.push({ method, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), roles, fn });

route('POST', '/api/auth/request-otp', null, async ({ body }) => {
  if (!phoneOk(body.phone)) bad(400, 'Enter a valid phone number');
  const phone = normPhone(body.phone), code = String(crypto.randomInt(100000, 1000000));
  db.prepare('INSERT OR REPLACE INTO otps VALUES(?,?,?,0)').run(phone, code, Date.now() + 5 * 60e3);
  await sendSms(phone, `Your Home2Place login code is ${code}`);
  return DEV_OTP ? { sent: true, dev_otp: code } : { sent: true };
});
route('POST', '/api/auth/verify', null, ({ body }) => {
  if (!phoneOk(body.phone)) bad(400, 'Enter a valid phone number');
  const phone = normPhone(body.phone), row = db.prepare('SELECT * FROM otps WHERE phone=?').get(phone);
  if (!row || row.exp < Date.now() || row.tries >= 5) bad(400, 'Code expired. Request a new one.');
  if (row.code !== String(body.otp)) { db.prepare('UPDATE otps SET tries=tries+1 WHERE phone=?').run(phone); bad(400, 'That code is not right'); }
  db.prepare('DELETE FROM otps WHERE phone=?').run(phone);
  let u = db.prepare('SELECT * FROM users WHERE phone=?').get(phone);
  if (!u) {
    const role = phone === normPhone(ADMIN_PHONE || '0') ? 'admin' : (body.role === 'partner' ? 'partner' : 'customer');
    db.prepare('INSERT INTO users(phone,name,role,partner_status,created) VALUES(?,?,?,?,?)').run(phone, String(body.name || '').slice(0, 60), role, role === 'partner' ? 'pending' : null, now());
    u = db.prepare('SELECT * FROM users WHERE phone=?').get(phone);
  }
  return { token: makeToken(u), user: u };
});
route('GET', '/api/me', ['customer', 'partner', 'admin'], ({ user }) => ({ user }));
route('POST', '/api/quote', null, ({ body }) => { const km = +body.km; if (!(km > 0 && km < 100)) bad(400, 'Distance must be between 0 and 100 km'); return quote(km); });

route('POST', '/api/orders', ['customer'], ({ user, body }) => {
  const km = +body.km; if (!(km > 0 && km < 100)) bad(400, 'Distance must be between 0 and 100 km');
  const need = [body.item, body.pickup && body.pickup.address, body.drop && body.drop.address, body.recipient && body.recipient.name, body.recipient && body.recipient.phone];
  if (need.some(x => !x || !String(x).trim())) bad(400, 'Please fill in item, addresses and recipient');
  const method = ['UPI', 'Card', 'Wallet', 'Cash'].includes(body.payMethod) ? body.payMethod : bad(400, 'Choose a payment method');
  const q = quote(km), id = 'H2P' + (18000 + db.prepare('SELECT COUNT(*) c FROM orders').get().c + 1), otp = String(crypto.randomInt(1000, 10000));
  db.prepare(`INSERT INTO orders VALUES(?,?,NULL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NULL,?,?)`).run(
    id, user.id, body.item, 'requested', body.pickup.address, body.pickup.name || user.name, body.pickup.phone || user.phone, body.drop.address,
    body.recipient.name, body.recipient.phone, body.recipient.note || '', body.when || 'now',
    q.km, q.base, q.dist, q.fee, q.total, q.partner_pay, method, method === 'Cash' ? 'cod' : 'pending', otp, now());
  event(id, 'requested');
  return { order: publicOrder(db.prepare('SELECT * FROM orders WHERE id=?').get(id), 'customer') };
});
route('GET', '/api/orders', ['customer', 'partner', 'admin'], ({ user, query }) => {
  let rows;
  if (user.role === 'customer') rows = db.prepare('SELECT * FROM orders WHERE customer_id=? ORDER BY created DESC').all(user.id);
  else if (user.role === 'partner') rows = db.prepare('SELECT * FROM orders WHERE partner_id=? ORDER BY created DESC').all(user.id);
  else rows = db.prepare('SELECT o.*, c.name customer_name, p.name partner_name FROM orders o LEFT JOIN users c ON c.id=o.customer_id LEFT JOIN users p ON p.id=o.partner_id ORDER BY o.created DESC').all();
  if (query.status) rows = rows.filter(o => o.status === query.status);
  return { orders: rows.map(o => publicOrder(o, user.role)) };
});
route('GET', '/api/orders/:id', ['customer', 'partner', 'admin'], ({ user, params }) => {
  const o = db.prepare('SELECT * FROM orders WHERE id=?').get(params.id);
  if (!o || (user.role === 'customer' && o.customer_id !== user.id) || (user.role === 'partner' && o.partner_id !== user.id)) bad(404, 'Order not found');
  const p = o.partner_id ? db.prepare('SELECT name, phone FROM users WHERE id=?').get(o.partner_id) : null;
  return { order: publicOrder(o, user.role), partner: p };
});
route('POST', '/api/orders/:id/cancel', ['customer'], ({ user, params }) => {
  const o = db.prepare('SELECT * FROM orders WHERE id=? AND customer_id=?').get(params.id, user.id);
  if (!o) bad(404, 'Order not found');
  if (!['requested', 'accepted'].includes(o.status)) bad(400, 'This order can no longer be cancelled');
  db.prepare("UPDATE orders SET status='cancelled' WHERE id=?").run(o.id); event(o.id, 'cancelled'); return { ok: true };
});

route('POST', '/api/payments/create', ['customer'], async ({ user, body }) => {
  const o = db.prepare('SELECT * FROM orders WHERE id=? AND customer_id=?').get(body.orderId, user.id);
  if (!o) bad(404, 'Order not found'); if (o.pay_status !== 'pending') bad(400, 'Nothing to pay for this order');
  const r = await rzpCreate(o.total, o.id);
  db.prepare('UPDATE orders SET rzp_order=? WHERE id=?').run(r.id, o.id);
  return { razorpay_order_id: r.id, amount: o.total * 100, currency: 'INR', key: RZP_ID || null, dev: !!r.dev };
});
route('POST', '/api/payments/verify', ['customer'], ({ user, body }) => {
  const o = db.prepare('SELECT * FROM orders WHERE id=? AND customer_id=?').get(body.orderId, user.id);
  if (!o || !o.rzp_order || o.rzp_order !== body.razorpay_order_id) bad(400, 'Payment does not match this order');
  if (!rzpVerify(o.rzp_order, body.razorpay_payment_id, body.razorpay_signature)) bad(400, 'Payment could not be verified');
  db.prepare("UPDATE orders SET pay_status='paid' WHERE id=?").run(o.id); return { ok: true };
});

route('GET', '/api/partner/jobs', ['partner'], ({ user }) => {
  if (user.partner_status !== 'approved') return { jobs: [], note: 'Your account is waiting for approval' };
  const rows = db.prepare("SELECT * FROM orders WHERE status='requested' AND pay_status IN ('paid','cod') ORDER BY created").all();
  return { jobs: rows.map(o => ({ id: o.id, item: o.item, pickup: o.pickup_addr, drop: o.drop_addr, km: o.km, earnings: o.partner_pay })) };
});
route('POST', '/api/partner/jobs/:id/accept', ['partner'], ({ user, params }) => {
  if (user.partner_status !== 'approved') bad(403, 'Your account is not approved yet');
  const r = db.prepare("UPDATE orders SET status='accepted', partner_id=? WHERE id=? AND status='requested' AND pay_status IN ('paid','cod')").run(user.id, params.id);
  if (!r.changes) bad(409, 'Another partner already took this job'); event(params.id, 'accepted'); return { ok: true };
});
const NEXT = { accepted: 'picked_up', picked_up: 'out_for_delivery' };
route('POST', '/api/orders/:id/advance', ['partner'], ({ user, params }) => {
  const o = db.prepare('SELECT * FROM orders WHERE id=? AND partner_id=?').get(params.id, user.id);
  if (!o) bad(404, 'Order not found'); const n = NEXT[o.status]; if (!n) bad(400, 'Nothing to update at this stage');
  db.prepare('UPDATE orders SET status=? WHERE id=?').run(n, o.id); event(o.id, n); return { status: n };
});
route('POST', '/api/orders/:id/deliver', ['partner'], ({ user, params, body }) => {
  const o = db.prepare('SELECT * FROM orders WHERE id=? AND partner_id=?').get(params.id, user.id);
  if (!o) bad(404, 'Order not found'); if (!['picked_up', 'out_for_delivery'].includes(o.status)) bad(400, 'Pick the item up first');
  if (String(body.otp) !== o.delivery_otp) bad(400, 'That OTP is not right. Ask the recipient again.');
  db.prepare("UPDATE orders SET status='delivered', pay_status=CASE WHEN pay_method='Cash' THEN 'paid' ELSE pay_status END WHERE id=?").run(o.id); event(o.id, 'delivered');
  return { ok: true, earned: o.partner_pay };
});
route('GET', '/api/partner/earnings', ['partner'], ({ user }) => {
  const d = db.prepare("SELECT o.partner_pay p, e.at at FROM orders o JOIN events e ON e.order_id=o.id AND e.status='delivered' WHERE o.partner_id=?").all(user.id);
  const day = s => s.slice(0, 10), today = day(now()), wk = Date.now() - 7 * 864e5, by = {};
  d.forEach(x => by[day(x.at)] = (by[day(x.at)] || 0) + x.p);
  return { today: by[today] || 0, week: d.filter(x => +new Date(x.at) > wk).reduce((a, x) => a + x.p, 0), deliveries: d.length, history: Object.keys(by).sort().reverse().map(k => ({ date: k, amount: by[k] })) };
});

route('GET', '/api/admin/stats', ['admin'], () => {
  const c = s => db.prepare(s).get().c, today = now().slice(0, 10);
  return {
    total: c('SELECT COUNT(*) c FROM orders'), completed: c("SELECT COUNT(*) c FROM orders WHERE status='delivered'"),
    active: c("SELECT COUNT(*) c FROM orders WHERE status IN ('requested','accepted','picked_up','out_for_delivery')"),
    revenue: c("SELECT COALESCE(SUM(total),0) c FROM orders WHERE status='delivered'"),
    today: c(`SELECT COUNT(*) c FROM orders WHERE created LIKE '${today}%'`),
    top_drops: db.prepare("SELECT drop_addr place, COUNT(*) n FROM orders GROUP BY drop_addr ORDER BY n DESC LIMIT 4").all()
  };
});
route('GET', '/api/admin/partners', ['admin'], ({ query }) => ({ partners: db.prepare('SELECT id, name, phone, partner_status, created FROM users WHERE role=\'partner\'' + (query.status ? ' AND partner_status=?' : '')).all(...(query.status ? [query.status] : [])) }));
route('POST', '/api/admin/partners/:id/verify', ['admin'], ({ params, body }) => {
  const s = body.approve ? 'approved' : 'rejected';
  const r = db.prepare("UPDATE users SET partner_status=? WHERE id=? AND role='partner'").run(s, params.id); if (!r.changes) bad(404, 'Partner not found'); return { status: s };
});

// ---- server ----
const MIME = { '.html': 'text/html; charset=utf-8', '.svg': 'image/svg+xml', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.ico': 'image/x-icon' };
function readBody(req) {
  return new Promise((res, rej) => { let d = ''; req.on('data', c => { d += c; if (d.length > 1e6) { rej(new HttpError(413, 'Request too large')); req.destroy(); } }); req.on('end', () => { try { res(d ? JSON.parse(d) : {}); } catch (e) { rej(new HttpError(400, 'Invalid JSON')); } }); });
}
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x'), send = (c, o) => { res.writeHead(c, { 'Content-Type': 'application/json', 'X-Content-Type-Options': 'nosniff' }); res.end(JSON.stringify(o)); };
  try {
    if (url.pathname.startsWith('/api/')) {
      const r = routes.find(r => r.method === req.method && r.re.test(url.pathname));
      if (!r) return send(404, { error: 'Not found' });
      let user = null;
      if (r.roles) {
        const t = readToken((req.headers.authorization || '').replace('Bearer ', ''));
        user = t && db.prepare('SELECT * FROM users WHERE id=?').get(t.uid);
        if (!user) return send(401, { error: 'Please log in' });
        if (!r.roles.includes(user.role)) return send(403, { error: 'Not allowed' });
      }
      const body = req.method === 'POST' ? await readBody(req) : {};
      return send(200, await r.fn({ req, user, body, params: url.pathname.match(r.re).groups || {}, query: Object.fromEntries(url.searchParams) }));
    }
    let f = path.join(__dirname, 'public', url.pathname === '/' ? 'index.html' : url.pathname);
    if (!f.startsWith(path.join(__dirname, 'public')) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' }); fs.createReadStream(f).pipe(res);
  } catch (e) {
    if (e instanceof HttpError) return send(e.code, { error: e.message });
    console.error(e); send(500, { error: 'Something went wrong' });
  }
});
if (require.main === module) server.listen(PORT, () => console.log(`Home2Place running on http://localhost:${PORT}`));
module.exports = { server };

// Shared by every page: talks to the Home2Place API and shows the login box.
(function () {
  var KEY = 'h2p_token', mem = null;
  function store(a, v) {
    try { if (a === 'g') return localStorage.getItem(KEY); if (a === 's') localStorage.setItem(KEY, v); else localStorage.removeItem(KEY); }
    catch (e) { if (a === 'g') return mem; mem = a === 's' ? v : null; }
  }
  var css = '.h2p-ov{position:fixed;inset:0;z-index:99;background:rgba(20,12,40,.55);display:grid;place-items:center;padding:18px}' +
    '.h2p-box{background:var(--bg,#fff);color:var(--ink,#2a2142);border-radius:20px;padding:26px;width:100%;max-width:380px;font:400 16px/1.5 Figtree,system-ui,sans-serif;box-shadow:0 20px 60px rgba(0,0,0,.3)}' +
    '.h2p-box h2{font:800 24px/1.1 "Bricolage Grotesque",Georgia,sans-serif;margin:0 0 6px}.h2p-box p{margin:0 0 14px;color:var(--muted,#6f6788)}' +
    '.h2p-box label{display:block;font-size:14px;font-weight:600;margin:12px 0 6px}' +
    '.h2p-box input{width:100%;font:inherit;color:inherit;background:var(--bg,#fff);border:1.5px solid var(--line,#e6dff7);border-radius:12px;padding:12px 14px}' +
    '.h2p-box button{width:100%;margin-top:16px;border:0;border-radius:12px;padding:14px;font:700 17px Figtree,sans-serif;background:var(--brand,#b79cf2);color:var(--brand-ink,#2a1659);cursor:pointer}' +
    '.h2p-box button.o{background:none;border:1.5px solid var(--line,#e6dff7);color:inherit;font-weight:600}' +
    '.h2p-err{color:#d33;font-size:14px;min-height:1.3em;margin:8px 0 0}.h2p-dev{background:var(--sel,#ece5fc);border-radius:10px;padding:8px 12px;font-size:14px;margin-top:10px}' +
    '.h2p-out{position:fixed;top:6px;right:8px;z-index:50;border:0;background:none;color:var(--muted,#6f6788);font:500 12px Figtree,sans-serif;text-decoration:underline;cursor:pointer}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  var H = window.H2P = {
    call: function (method, path, body) {
      var h = { 'Content-Type': 'application/json' }, t = store('g'); if (t) h.Authorization = 'Bearer ' + t;
      return fetch(path, { method: method, headers: h, body: body ? JSON.stringify(body) : undefined }).then(function (r) {
        return r.json().then(function (j) {
          if (!r.ok) { if (r.status === 401) store('r'); var e = new Error(j.error || 'Something went wrong'); e.status = r.status; throw e; }
          return j;
        }, function () { throw new Error('Something went wrong'); });
      }, function () { throw new Error('Cannot reach the server. Check your connection.'); });
    },
    logout: function () { store('r'); location.reload(); },
    esc: function (s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); },
    // Make sure someone with this role is logged in, then call cb(user).
    require: function (role, cb) {
      function ready(u) {
        var b = document.createElement('button'); b.className = 'h2p-out'; b.textContent = 'Log out (' + (u.name || u.phone) + ')'; b.onclick = H.logout; document.body.appendChild(b); cb(u);
      }
      function mismatch(u) {
        box('<h2>Wrong account</h2><p>You are logged in as a ' + H.esc(u.role) + '. This page is for ' + (role === 'admin' ? 'the admin' : 'a ' + role) + '.</p><button id="o">Log out and switch account</button>');
        document.getElementById('o').onclick = H.logout;
      }
      var ov;
      function box(html) { if (!ov) { ov = document.createElement('div'); ov.className = 'h2p-ov'; document.body.appendChild(ov); } ov.innerHTML = '<div class="h2p-box" role="dialog" aria-modal="true">' + html + '</div>'; return ov; }
      function login() {
        var title = role === 'partner' ? 'Partner login' : role === 'admin' ? 'Admin login' : 'Log in to Home2Place';
        box('<h2>' + title + '</h2><p>Enter your mobile number. We will send a code.</p><label for="ph">Mobile number</label><input id="ph" type="tel" inputmode="tel" placeholder="98765 43210" autocomplete="tel"><p class="h2p-err" id="er"></p><button id="go">Send code</button>');
        var ph = document.getElementById('ph'), er = document.getElementById('er'), go = document.getElementById('go');
        ph.focus();
        go.onclick = function () {
          er.textContent = ''; go.disabled = true;
          H.call('POST', '/api/auth/request-otp', { phone: ph.value }).then(function (r) { code(ph.value, r.dev_otp); }, function (e) { er.textContent = e.message; go.disabled = false; });
        };
      }
      function code(phone, dev) {
        box('<h2>Enter your code</h2><p>We sent a code to ' + H.esc(phone) + '.</p><label for="cd">Code</label><input id="cd" inputmode="numeric" maxlength="6" autocomplete="one-time-code">' +
          (role === 'admin' ? '' : '<label for="nm">Your name (first time only)</label><input id="nm" autocomplete="name">') +
          (dev ? '<div class="h2p-dev">Test mode: your code is <b>' + H.esc(dev) + '</b></div>' : '') +
          '<p class="h2p-err" id="er"></p><button id="go">Log in</button><button class="o" id="bk">Use a different number</button>');
        var er = document.getElementById('er'), go = document.getElementById('go'); document.getElementById('cd').focus();
        document.getElementById('bk').onclick = login;
        go.onclick = function () {
          er.textContent = ''; go.disabled = true;
          var nm = document.getElementById('nm');
          H.call('POST', '/api/auth/verify', { phone: phone, otp: document.getElementById('cd').value, role: role, name: nm ? nm.value : '' }).then(function (r) {
            store('s', r.token); if (ov) { ov.remove(); ov = null; } check(r.user);
          }, function (e) { er.textContent = e.message; go.disabled = false; });
        };
      }
      function check(u) { if (u.role === role) ready(u); else { H.call('GET', '/api/me').then(function () { mismatch(u); }); } }
      if (store('g')) H.call('GET', '/api/me').then(function (r) { check(r.user); }, login); else login();
    }
  };
})();

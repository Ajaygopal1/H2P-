# Home2Place: backend

A working backend for the Home2Place design: phone-OTP login, orders, pricing,
payments (Razorpay), partner jobs with delivery OTP, earnings and an admin API.
No dependencies. It needs **Node 22.5 or newer** and nothing else.

## Run it (2 minutes)

    cp .env.example .env      # then edit SECRET and ADMIN_PHONE
    npm start                 # http://localhost:3000
    npm test                  # runs the full order lifecycle check

`public/` holds the six pages, now connected to the API:

| Page | Who | Address |
| --- | --- | --- |
| `index.html` | Everyone (landing page) | `/` |
| `booking.html` | Customer: book and pay | `/booking.html` |
| `dashboard.html` | Customer: orders and live tracking | `/dashboard.html` |
| `partner.html` | Partner: jobs, delivery OTP, earnings | `/partner.html` |
| `admin.html` | Admin: stats, orders, partner approval | `/admin.html` |

Each page shows a login box on first visit (`api.js`). In test mode the login
code is shown on screen. The admin page only works for the `ADMIN_PHONE` number.

## How it works

| Who | What they can do |
| --- | --- |
| Customer | Log in with phone OTP, get a quote, book, pay, see own orders, cancel before pickup |
| Partner | Sign up (starts as *pending*), see jobs once approved, accept, mark picked up / out for delivery, deliver with the recipient's OTP, see earnings |
| Admin | See stats, list partners, approve or reject them, see all orders |

The first person to log in with `ADMIN_PHONE` becomes the admin.

Order status: `requested → accepted → picked_up → out_for_delivery → delivered`
(or `cancelled`). Partners only see orders that are paid (or cash on delivery).
Price: ₹30 base + ₹5.2/km + ₹5 platform fee. The partner earns base + distance.

## API (JSON; send `Authorization: Bearer <token>`)

    POST /api/auth/request-otp   {phone}
    POST /api/auth/verify        {phone, otp, role?, name?}  -> {token}
    GET  /api/me
    POST /api/quote              {km}
    POST /api/orders             {item, km, payMethod, pickup:{address,name,phone}, drop:{address}, recipient:{name,phone,note}, when}
    GET  /api/orders             GET /api/orders/:id        POST /api/orders/:id/cancel
    POST /api/payments/create    {orderId}
    POST /api/payments/verify    {orderId, razorpay_order_id, razorpay_payment_id, razorpay_signature}
    GET  /api/partner/jobs       POST /api/partner/jobs/:id/accept
    POST /api/orders/:id/advance POST /api/orders/:id/deliver {otp}
    GET  /api/partner/earnings
    GET  /api/admin/stats        GET /api/admin/partners?status=pending
    POST /api/admin/partners/:id/verify {approve: true|false}

## Before real customers use it

1. **Payments:** create a Razorpay account, put the key id and secret in `.env`.
   Until then payments are simulated. In the browser, open Razorpay Checkout with
   the `razorpay_order_id` from `/api/payments/create`, then send the three values
   it returns to `/api/payments/verify`. Never trust the browser alone: the server checks the signature.
2. **SMS login codes:** edit `sendSms()` in `server.js` to call your SMS provider
   (MSG91, Fast2SMS, Twilio). Then set `DEV_OTP=0` so codes stop appearing in API replies.
3. **Secret:** set `SECRET` to a long random value (`openssl rand -hex 32`).
4. **Hosting:** run on any server with Node 22.5+ (Railway, Render, a VPS) behind
   HTTPS, and keep `home2place.db` on a persistent disk. Back it up daily.
5. **Rules and trust:** partner KYC (Aadhaar, licence) review, terms, privacy
   policy and your local business and payment compliance. Please get proper advice.

## What's left

- **Distance:** the customer types the approximate distance in km. Add Google Maps
  or Mapbox to measure it from the two addresses and to show the rider on a real map.
- Live rider location, push or WhatsApp notifications, refunds, ratings, promotions.
- Pages that still say "Coming soon": saved addresses, wallet, history filters,
  customers, payments, complaints, pricing, locations, reports, settings.
- Move from SQLite to Postgres if you grow beyond one server.
- If a customer changes payment method after a failed payment, the first unpaid order stays in the database.

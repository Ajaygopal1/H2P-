// End-to-end check of the whole flow. Run: npm test
process.env.DB_FILE = ':memory:'; process.env.ADMIN_PHONE = '+919999999999'; process.env.DEV_OTP = '1';
const assert = require('node:assert');
const { server } = require('./server.js');
server.listen(0, async () => {
  const base = 'http://localhost:' + server.address().port;
  const call = async (m, p, body, tok) => { const r = await fetch(base + p, { method: m, headers: { 'Content-Type': 'application/json', ...(tok ? { Authorization: 'Bearer ' + tok } : {}) }, body: body ? JSON.stringify(body) : undefined }); return { s: r.status, j: await r.json() }; };
  const login = async (phone, role, name) => { const a = await call('POST', '/api/auth/request-otp', { phone }); const b = await call('POST', '/api/auth/verify', { phone, otp: a.j.dev_otp, role, name }); return b.j.token; };
  try {
    const cust = await login('9876543210', 'customer', 'Neha Sharma');
    const part = await login('9123456789', 'partner', 'Rajesh Kumar');
    const admin = await login('9999999999');
    assert.equal((await call('GET', '/api/me', null, admin)).j.user.role, 'admin');
    assert.equal((await call('POST', '/api/quote', { km: 5.8 })).j.total, 65, 'quote matches the design: ₹65 for 5.8 km');
    assert.equal((await call('GET', '/api/orders', null)).s, 401, 'login required');
    assert.equal((await call('GET', '/api/admin/stats', null, cust)).s, 403, 'customers cannot see admin');

    const o = (await call('POST', '/api/orders', { item: 'Lunch Box', km: 5.8, payMethod: 'UPI', pickup: { address: '2, Huzurganj' }, drop: { address: 'ABC College' }, recipient: { name: 'Rahul Kumar', phone: '+919123456780' } }, cust)).j.order;
    assert.equal(o.total, 65);
    assert.equal((await call('GET', '/api/partner/jobs', null, part)).j.jobs.length, 0, 'unapproved partner sees nothing');
    const pid = (await call('GET', '/api/admin/partners?status=pending', null, admin)).j.partners[0].id;
    await call('POST', `/api/admin/partners/${pid}/verify`, { approve: true }, admin);
    assert.equal((await call('GET', '/api/partner/jobs', null, part)).j.jobs.length, 0, 'unpaid order is hidden from partners');

    const pay = (await call('POST', '/api/payments/create', { orderId: o.id }, cust)).j;
    assert.equal((await call('POST', '/api/payments/verify', { orderId: o.id, razorpay_order_id: pay.razorpay_order_id, razorpay_payment_id: 'pay_x', razorpay_signature: 'x' }, cust)).s, 200);
    const jobs = (await call('GET', '/api/partner/jobs', null, part)).j.jobs; assert.equal(jobs.length, 1);
    assert.equal((await call('POST', `/api/partner/jobs/${o.id}/accept`, null, part)).s, 200);
    assert.equal((await call('POST', `/api/partner/jobs/${o.id}/accept`, null, part)).s, 409, 'cannot accept twice');
    await call('POST', `/api/orders/${o.id}/advance`, null, part); await call('POST', `/api/orders/${o.id}/advance`, null, part);
    assert.equal((await call('POST', `/api/orders/${o.id}/deliver`, { otp: '0000' }, part)).s, 400, 'wrong OTP is rejected');
    const otp = (await call('GET', `/api/orders/${o.id}`, null, cust)).j.order.delivery_otp;
    const d = await call('POST', `/api/orders/${o.id}/deliver`, { otp }, part); assert.equal(d.s, 200); assert.equal(d.j.earned, 60);
    assert.equal((await call('GET', '/api/partner/earnings', null, part)).j.today, 60);
    const st = (await call('GET', '/api/admin/stats', null, admin)).j; assert.equal(st.completed, 1); assert.equal(st.revenue, 65);
    console.log('All checks passed ✔');
  } catch (e) { console.error('FAILED:', e.message); process.exitCode = 1; }
  server.close();
});
